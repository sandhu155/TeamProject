const express = require('express')
const app = express()

app.use(express.static('frontend'));

app.set('view engine', 'ejs')

app.get('/', (req, res) => {
    console.log('Here')
    res.render("index", { text: "World"})
})

app.get('/users', (req, res) => {
    res.send("User List")
})

app.get('/users/new', (req, res) => {
    res.send("User New Form")
})

app.listen(3000)

